package bgu.spl.mics.application.messages;
import bgu.spl.mics.Event;

// raz built.


public class DeactivationEvent implements Event<Boolean> {
}
