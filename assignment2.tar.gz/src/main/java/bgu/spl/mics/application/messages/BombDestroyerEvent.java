package bgu.spl.mics.application.messages;

public class BombDestroyerEvent {
}
