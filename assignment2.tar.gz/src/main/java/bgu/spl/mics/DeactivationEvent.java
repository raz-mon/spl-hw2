package bgu.spl.mics;


// raz built.


public class DeactivationEvent {
}
